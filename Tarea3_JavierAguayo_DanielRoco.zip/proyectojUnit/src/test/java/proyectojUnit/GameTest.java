package proyectojUnit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class GameTest {

	private Game game;
	
	@BeforeEach
    void setUp() {
        game = new Game("TestGame", "RPG", "PC", 100, 5000);
    }

    @AfterEach
    void tearDown() {
        game = null;
    }

    @Test
    void testGetName() {
        assertEquals("TestGame", game.getTitle());
    }

    @Test
    void testGetGenre() {
        assertEquals("RPG", game.getGenre());
    }

    @Test
    void testGetPlatform() {
        assertEquals("PC", game.getPlatform());
    }

    @Test
    void testGetQuantity() {
        assertEquals(100, game.getQuantity());
    }

    @Test
    void testGetPrice() {
        assertEquals(5000, game.getPrice());
    }

    @Test
    void testSetName() {
        game.setTitle("NewTestGame");
        assertEquals("NewTestGame", game.getTitle());
    }

    @Test
    void testSetGenre() {
        game.setGenre("Adventure");
        assertEquals("Adventure", game.getGenre());
    }

    @Test
    void testSetPlatform() {
        game.setPlatform("PlayStation 4");
        assertEquals("PlayStation 4", game.getPlatform());
    }

    @Test
    void testSetQuantity() {
        game.setQuantity(150);
        assertEquals(150, game.getQuantity());
    }

    @Test
    void testSetPrice() {
        game.setPrice(6000);
        assertEquals(6000, game.getPrice());

    }

}
