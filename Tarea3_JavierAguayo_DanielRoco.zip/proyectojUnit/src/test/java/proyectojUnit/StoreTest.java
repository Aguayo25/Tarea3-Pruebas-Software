package proyectojUnit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.*;

public class StoreTest {

	private Store store;
    private Game game1;
    private Game game2;
    private Game game3;
    
    @BeforeEach
    void setUp() {
        store = new Store();
        game1 = new Game("game1", "RPG", "PlayStation 4", 100, 50000);
        game2 = new Game("game2", "Action", "Xbox One", 50, 40000);
        game3 = new Game("game3", "Adventure", "PC", 40, 20000);
    }
    
    @Test
    void testBuyGameAsCustomer() {
        store.addGame(game1);
        store.addGame(game2);
        store.addGame(game3);

        store.buyGameAsCustomer("game1", 5);
        assertEquals(95, game1.getQuantity());
    }
    
    @Test
    void testBuyGameAsAdmin() {
        store.addGame(game1);
        store.addGame(game2);
        store.addGame(game3);

        store.buyGameAsAdmin("game1", 10);
        assertEquals(110, game1.getQuantity());
    }
    
    @Test
    void testSellGameAsAdmin() {
        store.addGame(game1);
        store.addGame(game2);
        store.addGame(game3);
        
        store.sellGameAsAdmin("game1", 10);
        assertEquals(90, game1.getQuantity());
    }
    
    //Se verifica de que tras desplegar el catalogo, aparezca por pantalla el capturedOutput respectivo
    @Test
    void testCatalogDisplay() {
    	store.addGame(game1);
        store.addGame(game2);
        store.addGame(game3);

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(outputStream);

        PrintStream originalOut = System.out;
        System.setOut(printStream);

        store.displayCatalog();

        System.setOut(originalOut);

        String capturedOutput = outputStream.toString();

        assertTrue(capturedOutput.contains("game1"));
        assertTrue(capturedOutput.contains("RPG"));
        assertTrue(capturedOutput.contains("PlayStation 4"));
        assertTrue(capturedOutput.contains("100"));
        assertTrue(capturedOutput.contains("50000"));
        assertTrue(capturedOutput.contains("game2"));
        assertTrue(capturedOutput.contains("Action"));
        assertTrue(capturedOutput.contains("Xbox One"));
        assertTrue(capturedOutput.contains("50"));
        assertTrue(capturedOutput.contains("40000"));
        assertTrue(capturedOutput.contains("game3"));
        assertTrue(capturedOutput.contains("Adventure"));
        assertTrue(capturedOutput.contains("PC"));
        assertTrue(capturedOutput.contains("40"));
        assertTrue(capturedOutput.contains("20000"));
    }
    
  //Se verifica de que tras desplegar el catalogo, aparezca por pantalla el capturedOutput respectivo
    @Test
    void testDisplayCatalogAfterBuyingGame() {
        store.addGame(game1);
        store.addGame(game2);
        store.addGame(game3);

        store.buyGameAsCustomer("game1", 1);

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(outputStream);

        PrintStream originalOut = System.out;
        System.setOut(printStream);

        store.displayCatalog();

        System.setOut(originalOut);

        String capturedOutput = outputStream.toString();

        assertTrue(capturedOutput.contains("game1"));
        assertTrue(capturedOutput.contains("RPG"));
        assertTrue(capturedOutput.contains("PlayStation 4"));
        assertTrue(capturedOutput.contains("99")); //Game Sell
        assertTrue(capturedOutput.contains("50000"));
        assertTrue(capturedOutput.contains("game2"));
        assertTrue(capturedOutput.contains("Action"));
        assertTrue(capturedOutput.contains("Xbox One"));
        assertTrue(capturedOutput.contains("50"));
        assertTrue(capturedOutput.contains("40000"));
        assertTrue(capturedOutput.contains("game3"));
        assertTrue(capturedOutput.contains("Adventure"));
        assertTrue(capturedOutput.contains("PC"));
        assertTrue(capturedOutput.contains("40"));
        assertTrue(capturedOutput.contains("20000"));

        assertFalse(capturedOutput.contains("100"));
    }
    
  //Se verifica de que tras desplegar el catalogo, aparezca por pantalla el capturedOutput respectivo
    @Test
    void testGenerateReport() {
    	store.addGame(game1);
        store.addGame(game2);

        store.buyGameAsCustomer("game1", 2);

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(outputStream);

        PrintStream originalOut = System.out;
        System.setOut(printStream);

        store.generateReport();

        System.setOut(originalOut);

        String capturedOutput = outputStream.toString();

        assertTrue(capturedOutput.contains("Ventas realizadas: 0"));
        assertTrue(capturedOutput.contains("Compras realizadas: 2"));
        assertTrue(capturedOutput.contains("Ingresos generados: 100000"));

    }
    
    @Test
    void testDisplayInventoryForAdmin() {
    	store.addGame(game1);

        store.buyGameAsCustomer("game1", 2);

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(outputStream);

        PrintStream originalOut = System.out;
        System.setOut(printStream);

        store.displayInventoryForAdmin();

        System.setOut(originalOut);

        String capturedOutput = outputStream.toString();

        assertTrue(capturedOutput.contains("game1"));
        assertTrue(capturedOutput.contains("98"));
        assertTrue(capturedOutput.contains("40000"));
        assertTrue(capturedOutput.contains("50000"));
        assertTrue(capturedOutput.contains("RPG"));
    }
    
    
}
