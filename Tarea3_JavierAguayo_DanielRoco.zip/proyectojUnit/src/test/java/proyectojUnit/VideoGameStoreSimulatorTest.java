package proyectojUnit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Scanner;


public class VideoGameStoreSimulatorTest {
	
	@BeforeEach
	protected void setUp() throws Exception {
	}

	@AfterEach
	protected void tearDown() throws Exception {
	}
	
	@Test
    void testValidateAdminCredentials() {
        assertTrue(VideoGameStoreSimulator.validateAdminCredentials("admin", "123"));
        assertFalse(VideoGameStoreSimulator.validateAdminCredentials("admin", "wrongpassword"));
        assertFalse(VideoGameStoreSimulator.validateAdminCredentials("wrongusername", "123"));
        assertFalse(VideoGameStoreSimulator.validateAdminCredentials("wrongusername", "wrongpassword"));
    }
	
	@Test
    void testAdminMenu() {
        Store store = new Store();
        Game game1 = new Game("game1", "RPG", "PlayStation 4", 100, 50000);
        Game game2 = new Game("game2", "Action", "Xbox One", 50, 40000);
        store.addGame(game1);
        store.addGame(game2);

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(outputStream);
        System.setOut(printStream);

        String input = "admin\n123\n4\n6\n";
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(input.getBytes()));

        VideoGameStoreSimulator.adminMenu(store, new Scanner(System.in));

        System.setOut(System.out);
        System.setIn(stdin);

        String capturedOutput = outputStream.toString();
        assertTrue(capturedOutput.contains("Menú de Administrador"));
    }
	
	@Test
    void testCustomerMenu() {
        Store store = new Store();
        Game game1 = new Game("game1", "RPG", "PlayStation 4", 100, 50000);
        Game game2 = new Game("game2", "Action", "Xbox One", 50, 40000);
        store.addGame(game1);
        store.addGame(game2);

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(outputStream);
        System.setOut(printStream);

        String input = "1\n3\n";
        InputStream stdin = System.in;
        System.setIn(new ByteArrayInputStream(input.getBytes()));

        VideoGameStoreSimulator.customerMenu(store, new Scanner(System.in));

        System.setOut(System.out);
        System.setIn(stdin);

        String capturedOutput = outputStream.toString();
        assertTrue(capturedOutput.contains("Menú de Cliente"));
    }
	
}
