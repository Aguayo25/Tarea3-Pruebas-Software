package proyectojUnit;

import java.util.ArrayList;
import java.util.List;

public class Store {
    private List<Game> gameCatalog;
    private int totalbuy;
    private int totalSales;
    private double totalPurchases;

    public Store() {
        gameCatalog = new ArrayList<>();
        totalbuy = 0;
        totalSales = 0;
        totalPurchases = 0.0;
    }

    public void addGame(Game game) {
        gameCatalog.add(game);
    }

    public void displayCatalog() {
        System.out.println("Catálogo de juegos:");
        System.out.printf("%-10s %-10s %-12s %-8s %-8s\n", "Título", "Género", "Plataforma", "Cantidad", "Precio");
        for (Game game : gameCatalog) {
            System.out.printf("%-10s %-10s %-12s %-8d %-8.2f\n",
                    game.getTitle(), game.getGenre(), game.getPlatform(), game.getQuantity(), game.getPrice());
        }
    }

    public void buyGameAsCustomer(String title, int quantity) {
        for (Game game : gameCatalog) {
            if (game.getTitle().equals(title)) {
                if (game.getQuantity() >= quantity) {
                    game.setQuantity(game.getQuantity() - quantity);
                    double purchaseAmount = quantity * game.getPrice();
                    totalPurchases += purchaseAmount;
                    System.out.println(totalPurchases);
                    totalbuy += quantity;
                    System.out.println("Compra exitosa. Disfruta tu juego.\n");
                } else {
                    System.out.println("No hay suficiente stock disponible para la compra.\n");
                }
                return;
            }
        }
        System.out.println("El juego solicitado no está disponible en el catálogo.\n");
    }

    public void buyGameAsAdmin(String title, int quantity) {
        for (Game game : gameCatalog) {
            if (game.getTitle().equals(title)) {
                game.setQuantity(game.getQuantity() + quantity);
                double purchaseAmount = (quantity * game.getPrice()) * 0.8;
                totalPurchases -= purchaseAmount;
                totalbuy += quantity;
                System.out.println("Compra exitosa. Se ha actualizado la cantidad del juego.\n");
                return;
            }
        }
        System.out.println("El juego solicitado no está disponible en el catálogo.\n");
    }


    public void sellGameAsAdmin(String title, int quantity) {
        for (Game game : gameCatalog) {
            if (game.getTitle().equals(title)) {
                if (game.getQuantity() >= quantity) {
                    game.setQuantity(game.getQuantity() - quantity);
                    double purchaseAmount = quantity * game.getPrice();
                    totalPurchases += purchaseAmount;
                    totalSales += quantity;
                    System.out.println("Venta exitosa. Se ha actualizado el inventario y los ingresos.");
                } else {
                    System.out.println("No hay suficiente stock disponible para la venta");
                }
                return;
            }
        }
        System.out.println("El juego solicitado no está disponible en el catálogo");
    }

    public void displayInventoryForAdmin() {
        System.out.println("\nInventario de juegos:");
        System.out.println("--------------------------------------------------------------------------------");
        System.out.printf("%-15s %-10s %-10s %-10s  %-10s %-10s\n", "Título", "Cantidad", "Precio Compra", "Precio Venta", "Género", "Plataforma");
        System.out.println("--------------------------------------------------------------------------------");

        for (Game game : gameCatalog) {
            System.out.printf("%-15s %-10d %-13.2f %-13.2f %-10s %-10s\n",
                    game.getTitle(), game.getQuantity(), game.getPrice()* 0.8, game.getPrice(), game.getGenre(), game.getPlatform());
        }
        System.out.println("--------------------------------------------------------------------------------");
    }


    public void generateReport() {
        System.out.println("Reporte de la tienda:");
        System.out.println("Ventas realizadas: " + totalSales);
        System.out.println("Compras realizadas: " + totalbuy);
        System.out.println("Ingresos generados: " + totalPurchases );
        System.out.println("-----------------------------");
        System.out.println("Inventario actual:");

    }

}
