package proyectojUnit;

import java.util.Scanner;

public class VideoGameStoreSimulator {
    public static void main(String[] args) {
        Store store = new Store();

        Game game1 = new Game("game1", "RPG", "PlayStation 4", 100, 50000);
        Game game2 = new Game("game2", "Action", "Xbox One", 50, 40000);
        Game game3 = new Game("game3", "Adventure", "PC", 40, 20000);

        store.addGame(game1);
        store.addGame(game2);
        store.addGame(game3);

        Scanner scanner = new Scanner(System.in);

        System.out.println("Bienvenido a la Tienda de Videojuegos");

        while (true) {
            System.out.println("\nMenú principal");
            System.out.println("1. Cliente");
            System.out.println("2. Administrador");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            int option = scanner.nextInt();

            switch (option) {
                case 1:
                    customerMenu(store, scanner);
                    break;
                case 2:
                    adminMenu(store, scanner);
                    break;
                case 3:
                    System.out.println("Gracias por utilizar la tienda. ¡Hasta luego!");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Opción inválida. Por favor, seleccione una opción válida.");
            }
        }
    }

    public static void customerMenu(Store store, Scanner scanner) {
        while (true) {
            System.out.println("\nMenú de Cliente");
            System.out.println("1. Ver catálogo de juegos");
            System.out.println("2. Comprar juego");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            int option = scanner.nextInt();

            switch (option) {
                case 1:
                    store.displayCatalog();
                    break;
                case 2:
                    System.out.print("Ingrese el título del juego que desea comprar: ");
                    scanner.nextLine();
                    String buyTitle = scanner.nextLine();
                    System.out.print("Ingrese la cantidad deseada: ");
                    int buyQuantity = scanner.nextInt();
                    store.buyGameAsCustomer(buyTitle, buyQuantity);
                    break;
                case 3:
                    System.out.println("Gracias por utilizar la tienda como cliente. ¡Hasta luego!");
                    return;
                default:
                    System.out.println("Opción inválida. Por favor, seleccione una opción válida.");
            }
        }
    }

    public static void adminMenu(Store store, Scanner scanner) {
        System.out.print("Ingrese el nombre de usuario del administrador: ");
        String username = scanner.next();
        System.out.print("Ingrese la contraseña del administrador: ");
        String password = scanner.next();

        if (!validateAdminCredentials(username, password)) {
            System.out.println("Credenciales de administrador incorrectas. Acceso denegado.");
            return;
        }

        while (true) {
            System.out.println("\nMenú de Administrador");
            System.out.println("1. Ver catálogo de juegos");
            System.out.println("2. Comprar juego");
            System.out.println("3. Vender juego");
            System.out.println("4. Ver inventario de juegos");
            System.out.println("5. Generar reporte");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opción: ");
            int option = scanner.nextInt();

            switch (option) {
                case 1:
                    store.displayCatalog();
                    break;
                case 2:
                    System.out.print("Ingrese el título del juego que desea comprar: ");
                    scanner.nextLine();
                    String buyTitle = scanner.nextLine();
                    System.out.print("Ingrese la cantidad deseada: ");
                    int buyQuantity = scanner.nextInt();
                    store.buyGameAsAdmin(buyTitle, buyQuantity);
                    break;
                case 3:
                    System.out.print("Ingrese el título del juego que desea vender: ");
                    scanner.nextLine();
                    String sellTitle = scanner.nextLine();
                    System.out.print("Ingrese la cantidad deseada: ");
                    int sellQuantity = scanner.nextInt();
                    store.sellGameAsAdmin(sellTitle, sellQuantity);
                    break;
                case 4:
                    store.displayInventoryForAdmin();
                    break;
                case 5:
                    store.generateReport();
                    break;
                case 6:
                    System.out.println("Gracias por utilizar la tienda como administrador. ¡Hasta luego!");
                    return;
                default:
                    System.out.println("Opción inválida. Por favor, seleccione una opción válida.");
            }
        }
    }

    public static boolean validateAdminCredentials(String username, String password) {
        return username.equals("admin") && password.equals("123");
    }
}
